// Authentication System - Complete Version
document.addEventListener('DOMContentLoaded', function () {
    // Force redirect to login if not authenticated
    if (!localStorage.getItem('loggedIn')) {
        window.location.href = 'login.html';
        return;
    }

    // Update UI based on admin status
    updateUI();

    // Setup logout button
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function (e) {
            e.preventDefault();
            localStorage.clear();
            window.location.href = 'login.html';
        });
    }
});

function updateUI() {
    const isAdmin = localStorage.getItem('isAdmin') === 'true';
    const username = localStorage.getItem('username');

    // Update greeting
    const greeting = document.getElementById('userGreeting');
    if (greeting) {
        greeting.textContent = `Hello, ${username}${isAdmin ? ' (Admin)' : ''}`;
    }

    // Hide all admin-only elements if not admin
    if (!isAdmin) {
        document.querySelectorAll('.admin-only').forEach(el => {
            el.style.display = 'none';
        });
    }
}